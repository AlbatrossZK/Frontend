# GSAP preloader and hero animation

A Pen created on CodePen.

Original URL: [https://codepen.io/gridmorphic/pen/pvjXqeJ](https://codepen.io/gridmorphic/pen/pvjXqeJ).

GSAP powered website pre-loader & hero section animation inspired by capsules.moyra.co