# Random, Cos and Sin

A Pen created on CodePen.

Original URL: [https://codepen.io/soju22/pen/xxGqJxj](https://codepen.io/soju22/pen/xxGqJxj).

I like to play with polylines ^^ Click to randomize

I didn't use noise this time, just random, cos and sin